require "lua.Tools.toTool"
require "lua.Tools.callCS"

cjson = require "cjson"
cjson2 = cjson.new()

function StartMain()
	local port = 965
    ServerTools.Self.listenerUrls:Add("http://+:" .. port .. "/")
	ServerTools.Self:AddListener(function (_ctx)
		local core = require "lua.server.core"
		core.RequestCallback(_ctx)
	end)
	
	ServerTools.Self:StartServer()
	local url = "http://" .. ServerTools.GetLocalIP() .. ":" .. port
	log(url .. " ������...")

    while true do
        local cmd = io.read()
        if cmd == "cls" then
            os.execute("cls")
        elseif cmd == "start" then
            os.execute("start "..url)
        end
    end
end