local hunxiao = {}
local this = hunxiao

local function dellStr(str,data)
    str = string.gsub( str, "[ \t\n\r]+$", "")   --去后空格
    str = string.gsub( str, "^[ \t\n\r]+", "")   --去后空格
    str = string.gsub( str, "//.+$", "")   --去注释
    local haveLeft = false
    local haveRight = false
    if string.sub( str, 1,1 ) == "{" and not (string.sub( str, #str,#str ) == ",") then
        haveLeft = true
    end
    if string.sub( str,  #str, #str ) == "{" then
        log(str)
        data.cur = str
        haveLeft = true
    end

    if string.sub( str, #str,#str ) == "}" then
        haveRight = true
    elseif string.sub( str, #str - 1,#str ) == "};" then
        haveRight = true
    end

    local haveExNode = string.find( str,"//" )
    local haveExNodes = string.find( str,"/%*.*%*/" )
    local haveDelegate = string.find( str,"delegate" )
    local haveInterface = string.find( str,"interface" )
    local haveNamespace = string.find( str,"namespace" )
    local haveIf = string.find( str,"if" )
    local haveFor = string.find( str,"for" )
    local haveElse = string.find( str,"else" )
    local haveIfElse = string.find( str,"else if" )
    local haveClass = string.find( str,"class" )
    local haveStatic = string.find( str,"static" )
    local haveReturn = string.find( str,"return" )
    local haveBreak = string.find( str,"break" )
    local haveUsing = string.find( str,"using" )
    local haveWhile = string.find( str,"while" )
    local haveOver = string.find( str,";" )
    if haveOver then
        local lastChar = string.sub( str, #str, #str )
        haveOver = lastChar == ";"
    end

    if haveUsing then

    elseif haveOver and not haveReturn and not haveBreak then
        -- log("正常语句结束！")
    end

    if haveRight then
        table.remove(data.c,#data.c)
        local r = nil
        for i = 1, #data.c do
            if not r then
                r = data.a[data.c[i]]
            else
                r = r[data.c[i]]
            end
        end
        data.b = r
    end

    if haveLeft then
        if not data.b then
            data.b = {}
            data.a = data.b
            data.c = {}
        end
        table.insert(data.b,{ txt = data.cur})
        table.insert(data.c, #data.b)
        data.b = data.b[#data.b]
    end
    
    data.cur = str
end

local function dellLine(url)
    local result = ""

    local read = File.OpenText(url)
    local frist = true
    local str = nil
    local data = {}
    local lines = {}
    while frist or str do
        frist = false
        str = read:ReadLine()
        if str then
            str = string.gsub( str, "//.+$", "")   --去注释
            str = string.gsub( str, "/%*.*%*/", "")   --去注释
            str = string.gsub( str, "[ \t\n\r]+$", "")   --去后空格
            str = string.gsub( str, "^[ \t\n\r]+", "")   --去后空格


            if str ~= "" then
                
                if string.sub( str,#str,#str) == "{" and #str > 1 then
                    str = string.sub( str,1,#str - 1)
                    table.insert(lines,str)
                    table.insert(lines,"{")
                end
                
                -- if string.sub( str,1,1) == "}" then
                --     str = string.sub( str,1,#str - 1)
                --     table.insert(lines,str)
                --     table.insert(lines,"{")
                -- else
                -- end

                table.insert(lines,str)
            end
        end
    end
    -- log(table_tostring(a),url)
    return lines
end

function this.start()
    local projectUrl = [[E:\bf_allgame_lua\allgame\hb_bamengmj_2018]];
    if not Directory.Exists(projectUrl) then
        log("指定项目文件夹不存在!", projectUrl)
        return;
    end

    local tempDirName = projectUrl  .. [[\TempRegexTest]]
    local tempDirIdx = 1

    while Directory.Exists(tempDirName..tempDirIdx) do
        tempDirIdx = tempDirIdx + 1
    end
    tempDirName = tempDirName .. tempDirIdx

    local dellDirs = {
        [[\Assets\Code\GCloudVoiceEngine.cs]],
        -- [[\Assets\Code]],
        -- [[\Assets\Editor]],
        -- [[\Assets\LuaFramework\Editor]],
        -- [[\Assets\LuaFramework\Scripts]],
        -- [[\Assets\LuaFramework\ToLua\BaseType]],
        -- [[\Assets\LuaFramework\ToLua\Lua]],
        -- [[\Assets\LuaFramework\ToLua\Misc]],
        -- [[\Assets\LuaFramework\ToLua\Reflection]],

        
        -- [[\Assets\LuaFramework\ToLua\Core]],
        -- [[\Assets\LuaFramework\ToLua\Editor]],
    }

    local dontDellFile = {
        -- [[\LuaFramework\ToLua\Reflection\1.txt]],
    }

    for i = 1, #dontDellFile do
        local url = dontDellFile[i]
        local key = Path.GetFileName(dontDellFile[i])
        dontDellFile[key] = url
        dontDellFile[i] = nil
    end

    local allFiles = {}

    local getFilesFun = nil
    getFilesFun = function (url)
        if Directory.Exists(url) then
            local t = Directory.GetFileSystemEntries(url)
            local iter = t:GetEnumerator()
            while iter:MoveNext() do
                local fileUrl = iter.Current
                getFilesFun(fileUrl)
            end
        elseif File.Exists(url) then
            local key = Path.GetFileName(url)
            local ext = Path.GetExtension(url)

            if dontDellFile[key] then
                -- log("白名单文件不处理!", url) 
            elseif ext ~= ".cs" then
                -- log("不处理.cs!", url) 
            else
                table.insert(allFiles,url)
            end
        end
        -- local t = Directory.GetFileSystemEntries(url)
        -- local iter = t:GetEnumerator()
        -- while iter:MoveNext() do
        --     local fileUrl = iter.Current
        --     if Directory.Exists(fileUrl) then
        --         getFilesFun(fileUrl)
        --     else
        --     end
        -- end
    end

    for i = 1, #dellDirs do
        local dir = projectUrl .. dellDirs[i]
        getFilesFun(dir)
    end

    log(table_tostring(allFiles))


    for i = 1, #allFiles do
        local fileUrl = allFiles[i]

        local newTempFile = string.gsub(fileUrl, projectUrl, tempDirName)
        local newTempDir = Path.GetDirectoryName(newTempFile)
        if not Directory.Exists(newTempDir) then
            Directory.CreateDirectory(newTempDir);
        end
        -- File.Copy(fileUrl, newTempFile)
    end

    for i = 1, #allFiles do
        local fileUrl = allFiles[i]

        local newTempFile = string.gsub(fileUrl, projectUrl, tempDirName)
        local str = dellLine(fileUrl)
        -- File.WriteAllText(newTempFile, str, Encoding.UTF8);
        log(table_tostring(str))
        return 
    end
end

return this