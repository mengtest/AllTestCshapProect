local this = {}

local str = File.ReadAllText([[D:\8823.txt]])

return this