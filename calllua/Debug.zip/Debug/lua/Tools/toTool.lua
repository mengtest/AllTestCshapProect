JSON = require "Tools/toJson"

Tool = {}
local this = Tool

log = function (str)
	print("["..os.date("%Y-%m-%d %H:%M:%S").."]:"..str)
end

local r = require
require = function (str)
	package.loaded[str] = nil
	return r(str)
end

local function _list_table(tb, table_list, level, isMetatable)
	local ret = "";
	local indent = string.rep(" ", level * 4);
	
	for k, v in pairs(tb) do
		local quo = type(k) == "string" and '"' or "";
		ret = ret .. indent .. "[" .. quo .. tostring(k) .. quo .. "] = ";
		
		if type(v) == "table" then
			local t_name = table_list[v];
			if t_name then
				ret = ret .. tostring(v) .. ' -- > ["' .. t_name .. '"]\n';
			else
				table_list[v] = tostring(k);
				ret = ret .. "{\n";
				ret = ret .. _list_table(v, table_list, level + 1, isMetatable);
				ret = ret .. indent .. "},\n";
			end
		elseif type(v) == "string" then
			ret = ret .. '"' .. tostring(v) .. '",\n';
		else
			ret = ret .. tostring(v) .. ",\n";
		end
	end
	
	if isMetatable == true then
		local mt = getmetatable(tb);
		if mt then
			ret = ret .. "\n";
			local t_name = table_list[mt];
			ret = ret .. indent .. "<metatable> = ";
			if t_name then
				ret = ret .. tostring(mt) .. ' -- > [\"' .. t_name .. '\"]\n';
			else
				ret = ret .. "{\n";
				ret = ret .. _list_table(mt, table_list, level + 1, true);
				ret = ret .. indent .. "}\n";
			end
		end
	end
	return ret;
end

--��tableת��Ϊ�ַ�����ʾ
function table_tostring(tb, isMetatable, table_list)
	if type(tb) ~= "table" then
		error("Sorry 1, it's not table, it is " .. type(tb) .. ".\n" .. debug.traceback());
		return "";
	end
	if isMetatable == nil then isMetatable = false; end
	local ret = "{\n";
	table_list = table_list or {};
	table_list[tb] = "root table";
	ret = ret .. _list_table(tb, table_list, 1, isMetatable);
	ret = ret .. "}";
	return ret;
end

--json����
--@object: ԭʼ����
function CloneJsonData(object)
	if object == nil then
		error("2 ���Ƶ�ԭʼ����Ϊ nil����ջ���£�" .. "\n" .. debug.traceback());
		return nil;
	end
	local withOutType = {"nil", "function", "thread", "userdata"};
	local lookup_table = {};
	local function _copy(object)
		if type(object) ~= "table" then
			return object;
		elseif lookup_table[object] then
			return lookup_table[object];
		end
		local newObject = {};
		lookup_table[object] = newObject;
		for key, value in pairs(object) do
			if not table_conValue(withOutType, type(value)) then
				newObject[_copy(key)] = _copy(value);
			end
		end
		return setmetatable(newObject, getmetatable(object));
	end
	return _copy(object);
end

-- **************************λ����begin*******************************
bit = {data32 = {}};  --ĿǰֵֻҪ 4���ֽ�
for i = 1, 32 do
	bit.data32[i] = 2 ^(32 - i);
end

--bit:d2b ʮ����ת������
function bit:d2b(arg)
	local num = tonumber(arg);
	local tr = {};
	
	if num ~= nil then
		if num >= 0 then
			for i = 1, 32 do
				if num >= bit.data32[i] then
					num = num - bit.data32[i];
					tr[i] = 1;
				else
					tr[i] = 0;
				end
			end
			return tr;
		else
			return tr;					
		end								
	else
		return tr;
	end
end

--bit:b2d ������תʮ����
function bit:b2d(arg)
	local num = 0;
	if arg ~= nil then
		for i = 1, 32 do
			if	arg[i] == 1 then
				num = num + bit.data32[i];
			elseif arg[i] ~= 0 then
				return num;		
			end				
		end	
		return num;	
	else
		return num;
	end
end

--bit:xor
function bit:_xor(a, b)
	local op1 = self:d2b(a);
	local op2 = self:d2b(b);
	local r = {};
	
	for i = 1, 32 do
		if op1[i] == op2[i] then
			r[i] = 0;
		else
			r[i] = 1;
		end
	end
	return self:b2d(r);
end

--bit:_and
function bit:_and(arg1, arg2)
	local num1 = tonumber(arg1);
	local num2 = tonumber(arg2);
	
	if num1 == nil then
		return 0;
	end	
	
	if num2 == nil then
		return 0;
	end
	
	local tr1 = bit:d2b(num1);
	local tr2 = bit:d2b(num2);
	local tr3 = {};
	
	for i = 1, 32 do
		if tr1[i] == 1 and tr2[i] == 1 then
			tr3[i] = 1;
		else
			tr3[i] = 0;
		end
	end	
	return bit:b2d(tr3);
end

--bit:_or 
function bit:_or(arg1, arg2)
	local num1 = tonumber(arg1);
	local num2 = tonumber(arg2);
	
	if num1 == nil then
		return 0;
	end	
	
	if num2 == nil then
		return 0;
	end
	
	local tr1 = bit:d2b(num1);
	local tr2 = bit:d2b(num2);
	local tr3 = {};
	
	for i = 1, 32 do
		if tr1[i] == 0 and tr2[i] == 0 then
			tr3[i] = 0;
		else
			tr3[i] = 1;
		end
	end	
	return bit:b2d(tr3);
end

--bit:_not
function bit:_not(arg1)
	local a = tonumber(arg1);
	
	if a == nil then
		return 0;
	end	
	
	local op1 = self:d2b(a);
	local r = {};
	
	for i = 1, 32 do
		if op1[i] == 1 then
			r[i] = 0;
		else
			r[i] = 1;
		end
	end
	return self:b2d(r);
end
--�÷���
-- print(bit:_or(15, 10)) --���15
-- print(bit:_or(0xA, 0xF)) --���15
-- **************************λ����end*******************************

--��Ŀ����
function AndB(a, b, c)
	return(a and {b} or {c}) [1];
end

function unrequire(filename)
	filename = filename:replace('/', '.');
	package.loaded[filename] = nil;
end

function re_require(filename)
	unrequire(filename);
	return require(filename);
end

--��������
--@parameter decimal Ҫ��������
--@parameter n ��Ч��С��λ
function Round(decimal, n)
	n = n or 0;
	local decimalTemp = decimal *(10 ^ n);
	if decimalTemp % 1 >= 0.5 then
		decimalTemp = math.ceil(decimalTemp);
	else
		decimalTemp = math.floor(decimalTemp);
	end
	return decimalTemp /(10 ^ n);
end

--��ʵ���
function Random(...)
	math.randomseed(tostring(os.time()):reverse():sub(1, 6));
	local r = {}
	r.random = math.random
	return r
end

--@desc ��ȡ��ǰʱ��
--@return �ַ�����ʽ��%Y-%m-%d %H:%M:%S
function GetCurrentTime()
	return os.date("%Y-%m-%d %H:%M:%S");
end

--�ж�һ��table�Ƿ������key
function table_conKey(tb, key)
	if type(tb) ~= "table" then
		error("Sorry 4, it's not table, it is " .. type(tb) .. ".\n" .. debug.traceback());
		return nil;
	end
	for k, v in pairs(tb) do
		if k == key then
			return true;
		end
	end
	return false;
end

--�ж�һ��table�Ƿ������value
function table_conValue(tb, value)
	if type(tb) ~= "table" then
		error("Sorry 5, it's not table, it is " .. type(tb) .. ".\n" .. debug.traceback());
		return nil;
	end
	for k, v in pairs(tb) do
		if v == value then
			return true;
		end
	end
	return false;
end

--�ַ��滻����֧�����ģ�
function string.replace(str, replace_target, replace_string)
	if type(str) ~= "string" then
		warn("it's not string \n" .. debug.traceback());
		return "";
	end
	local ss = str:split(replace_target);
	local _s = ss[1];
	if #ss > 1 then
		for i = 2, #ss do
			_s = _s .. replace_string .. ss[i];
		end
	end
	return _s;
end

--��ȡ������׺�������ļ���
function GetFullFileNameWhithoutExtension(str)
	if type(str) ~= "string" then
		warn("it's not string \n" .. debug.traceback());
		return "";
	end
	local idx = str:match(".+()%.%w+$");
	if idx then
		return str:sub(1, idx - 1);
	else
		return str;
	end
end

--��ȡ������׺���ļ���
function GetFileNameWhithoutExtension(str)
	if type(str) ~= "string" then
		warn("it's not string \n" .. debug.traceback());
		return "";
	end
	local ret = GetFileName(str);
	return GetFullFileNameWhithoutExtension(ret);
end

--��ȡ��չ��
function GetExtension(str)
	if type(str) ~= "string" then
		warn("it's not string \n" .. debug.traceback());
		return "";
	end
	return "." .. str:match(".+%.(%w+)$");
end

--��ȡ�ļ���
function GetFileName(str)
	if type(str) ~= "string" then
		warn("it's not string \n" .. debug.traceback());
		return "";
	end
	local ret = str:split("/");
	return ret[#ret];
end

--ȥ���ַ������ߵĿո�
function string.trim(s)
	if type(s) ~= "string" then
		warn("it's not string \n" .. debug.traceback());
		return "";
	end
	local ret = string.gsub(s, "^%s*(.-)%s*$", "%1");
	return ret;
end

--�������ַ��ָ��ַ�������֧�����ģ�
function string.split(str, split_char)
	if type(str) ~= "string" then
		warn("it's not string \n" .. debug.traceback());
		return {};
	end
	local sub_str_tab = {};
	while true do
		local pos = string.find(str, split_char);
		if not pos then
			sub_str_tab[#sub_str_tab + 1] = str;
			break;
		end
		local sub_str = string.sub(str, 1, pos - 1);
		sub_str_tab[#sub_str_tab + 1] = sub_str;
		str = string.sub(str, pos + 1, #str);
	end
	return sub_str_tab;
end

--@desc ��ȡ�ַ�����֧�����ģ�
--@start_c: ��ʼ��������1��ʼ��
--@end_c: ��������
function lua_string_sub(inputstr, start_c, end_c)
	if type(inputstr) ~= "string" then
		warn("it's not string \n" .. debug.traceback());
		return "";
	end
	return utf8.sub(inputstr, start_c, end_c + 1);
end

--��ȿ���
--@object: ԭʼ���� ("nil", "number", "string", "boolean", "table", "function", "thread", "userdata")
function DataClone(object)
	if object == nil then
		error("1 ���Ƶ�ԭʼ����Ϊ nil����ջ���£�\n" .. debug.traceback());
		return nil;
	end
	local lookup_table = {};
	local function _copy(object)
		if type(object) ~= "table" then
			return object;
		elseif lookup_table[object] then
			return lookup_table[object];
		end
		local newObject = {};
		lookup_table[object] = newObject;
		for key, value in pairs(object) do
			newObject[_copy(key)] = _copy(value);
		end
		return setmetatable(newObject, getmetatable(object));
	end
	return _copy(object);
end

--@desc ����UNIXʱ�����ֵ(����1970.1.1������)
--@parameter _table ʱ��table�ĸ�ʽ˳���� �� �� ʱ �� ��
function TableToTimestamp(_table)
	local Y = tonumber(_table[1]) or 0;
	local m = tonumber(_table[2]) or 0;
	local d = tonumber(_table[3]) or 0;
	local H = tonumber(_table[4]) or 0;
	local M = tonumber(_table[5]) or 0;
	local S = tonumber(_table[6]) or 0;
	return os.time({year = Y, month = m, day = d, hour = H, min = M, sec = S});
end

--@desc UNIXʱ���ת�ַ��� Timestamp
--@parameter timeAmount ʱ��ֵ(��)
--@parameter format ��ʽ������
function TimestampToString(timeAmount, format)
	if format == nil then
		format = "%Y-%m-%d %H:%M:%S";
	end
	return os.date(format, timeAmount);
end

--��json��ʽ����table�������ؽ����Ĭ����������isPrint��Ϊfalse��������
function printT(table,isPrint)
	if table == nil then return nil end
	key = ""
	local result = ""
	local func = function(table,level) end
	func = function(table,level)
		level = level or 1
		local indent = ""
		for i = 1, level do
			indent = indent.."  "
		end

		if key ~= "" then
			result = result..indent..key.." ".."=".." ".."{\n"
		else
			result = result..indent .. "{\n"
		end

		key = ""
		for k,v in pairs(table) do
			if type(v) == "table" then
				key = k
				func(v,level + 1)
			else
				local content = string.format("%s%s = %s\n", indent .. "  ",tostring(k), tostring(v))
				result = result..content
			end
		end
		result = result..indent .. "}\n"
	end
	func(table)
	isPrint = isPrint == nil
	if isPrint then print(result) end
	return result
end

--��¡��������ֹ���ֱ�����
function this.clone( object )
    local lookup_table = {}
    local function copyObj( object )
        if type( object ) ~= "table" then
            return object
        elseif lookup_table[object] then
            return lookup_table[object]
        end

        local new_table = {}
        lookup_table[object] = new_table
        for key, value in pairs( object ) do
            new_table[copyObj( key )] = copyObj( value )
        end
        return setmetatable( new_table, getmetatable( object ) )
    end
    return copyObj( object )
end

--...����ɱ������#arg�����
function this.average(...)
   result = 0
   local arg={...}	--��������ֵΪtable
   for i,v in ipairs(arg) do
      result = result + v
   end
   --print("�ܹ����� " .. #arg .. " ����")
   return result / #arg   --��ƽ��ֵ
end

--��table���������������ֵ������
function this.maximum (a)
    local mi = 1             -- ���ֵ����
    local m = a[mi]          -- ���ֵ
    for i,val in ipairs(a) do
       if val > m then
           mi = i
           m = val
       end
    end
    return m, mi		--�ɷ��ض���������������ֵ�����ڵ�����
end

--������������ת��Ϊ���ĺ�������
--˼·��������tostring�����ڲ��Ҽ�ȡ���ֳ���
--      ��"5665"�У�����ʼ1��1��ȡ5������ʼ2��2��ȡ6���Դ�����
--      ���ַ���tonumber����ֵȡ���Ķ�Ӧ�±꣬����ƴ�ӣ����ؽ��
function this.NumToCN(num)
    local size = #tostring(num) 	--���������֣�tostringת��Ϊ�ַ����󳤶�
    local CN = ""
    local StrCN = {"һ","��","��","��","��","��","��","��","��"}
    for i = 1 , size do
        CN = CN .. StrCN[tonumber(string.sub(tostring(num), i , i))]
    end
    return CN
end

--��GB2312��ʽurl��ַ����Ϊ����
function this.GB2312_UrlCode_toString(s)
	s = string.gsub(s, "+", " ") 	--+Ϊ�ո�
	s = string.gsub(s, "%%([%w]+[%w]+)", 
		function (h) 
			return string.char(tonumber(h, 16)) 
		end) 
	return s
	--print(Tool.GB2312_UrlCode_toString("%d0%fd%c2%c9%cb%e6%b7%e7"))
end

--������ת��ΪGB2312
--���ؽ������
function this.String_UrlCode_GB2312(s,bAd,rStr)
	local result = {}
	local resultStr =""
	for i=1,#s do
		result[i] = string.byte(s,i,i)
		result[i] = string.format("%x",result[i])    -- %#X 16���������д������
													 -- %#x ͬ����Сд
													 -- %x ��������Сд
		if bAd == true then
			result[i] = "%" .. result[i]
		end
		resultStr = resultStr .. result[i]
	end
	if rStr == true then
		return resultStr
	end
	return result
	-- printT(Tool.String_UrlCode_GB2312("��ǧһ��",true))
	-- printT(Tool.String_UrlCode_GB2312("��ǧһ��"))
end

-- string���gsub������������������ 
-- 1. str�Ǵ��ָ���ַ��� 
-- 2. '[^'..reps..']+'���������ʽ�����ҷ�reps�ַ������Ҷ��ƥ�� 
-- 3. ÿ�ηָ�����ַ�������ͨ���ص�������ȡ����w�������Ƿָ���һ�����ַ������������浽һ��table��
function split( str,reps )
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+',function ( w )
        table.insert(resultStrList,w)
    end)
    return resultStrList
end

--String.split
function this.split(str, split_char)
    local sub_str_tab = {};
    while (true) do
        local pos = string.find(str, split_char);
        if (not pos) then
            sub_str_tab[#sub_str_tab + 1] = str;
            break;
        end
        local sub_str = string.sub(str, 1, pos - 1);
        sub_str_tab[#sub_str_tab + 1] = sub_str;
        str = string.sub(str, pos + 1, #str);
    end

    return sub_str_tab;
end

--Excel����
function this.newExecl()
	local obj = {}
	obj.excel = luacom.CreateObject("Excel.Application")
	obj.curSheet = nil	--��ǰ������
	obj.books = nil
	obj.c_url = nil
	
	function obj:openExcel(url,visible,sheet)
		visible = visible or false
		sheet = sheet or 1
		self.c_url = url
		self.excel.Visible = visible
		self.excel.Application.DisplayAlerts = 0
		if io.open(url,"r") == nil then
			self.books = self.excel.Workbooks:Add()
			self.books:Save(self.c_url)
			self.curSheet = self.books.Sheets(sheet)
			self.excel.Application.DisplayAlerts = 1
			return self
		else
			self.books = self.excel.WorkBooks:Open(url)
			self.curSheet = self.books.Sheets(sheet)
			self.excel.Application.DisplayAlerts = 1
		    return self
		end
	end
	
	function obj:selectSheet()
		self.books:Save()
		self.books:Close()
		self.curSheet = self.books.Sheets(sheet)
	end
	
	function obj:writeText(row,col,value)
		self.curSheet.Cells(row,col).Value2 = value
		return 1
	end
	
	function obj:readText(row,col)
		return self.curSheet.Cells(row,col).Value2	--��Excel����������ʾ���󣬵�����ֱ�����ļ���ʽ��������
	end
	
	function obj:quit()
		-- self.books:Close()
		self.excel:Quit()
		return 1
	end
	
	function obj:save()
		-- self.excel.Application.DisplayAlerts = 0
		self.excel.Application.DisplayAlerts = 0
		if io.open(self.c_url,"r") ~= nil then
			os.remove(self.c_url)
			self.books:SaveAs(self.c_url)
		else
			self.books:SaveAs(self.c_url)
		end
		self.excel.Application.DisplayAlerts = 1
		-- self.excel.Application.DisplayAlerts = 1
		-- self.books:SaveAs(self.c_url,51)--��ʽ��51xlsx -4143xls
		return 1
	end
	
	return obj
	
	-- obj = newExecl()
    -- obj:openExcel("d:\\222.xlsx")
    -- assert(obj:writeText(2,1,"11122211"))
    -- assert(obj:writeText(3,1,"ţ�� "))
    -- assert(obj:save())
    -- obj:quit()
end


function decodeURI(s)
	s = string.gsub(s, '%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end)
	return s
end

function encodeURI(s)
	s = string.gsub(s, "([^%w%.%- ])", function(c) return string.format("%%%02X", string.byte(c)) end)
	return string.gsub(s, " ", "+")
end


function NLog()
    local o = {}
    o.wait = {}
    o.idx = 1
    o.waitTime = 0.1
    o.isWrite = false
    o.writToFile = function()
        if o.wait[o.idx] then
            local str = o.wait[o.idx].log .. "\n"
            o.wait[o.idx] = nil
            o.idx = o.idx + 1
            local file = io.open("result.txt", "a")
            file:write(str)
            file:close()
        end
        o.isWrite = false
    end
    o.push =function ( idx,str )
        local num = tonumber(idx)
        if num == 1 then
            o.idx = 1
        end
        o.wait[num] = {
            ["log"] = str,
            ["idx"] = idx,
        }
    end
    o.init = function ()
        o.idx = 1
        o.isWrite = false
        o.wait = {}
    end
    return o
end


--key��value��ͬ�ı�
function tablt_v_on_k( tab )
    local newTab = {}
    for i=1,#tab do
        newTab[tab[i]] = tab[i]
    end
    return newTab
end



function NewStack()
    local tab = {}
    local stack = {}
    stack.count = 0
    function stack.clear()
        tab = {}
        stack.count = 0
    end
    function stack.pop()
        local o = tab[#tab]
        if o then
            table.remove(tab,#tab )
        end
        stack.count = #tab
        return o
    end
    function stack.push(o)
        table.insert(tab, o)
        stack.count = #tab
        return tab[#tab]
    end
    function stack.peek()
        return tab[#tab]
    end
    return stack;
end


function StringGmatch(str,findstr,fun)
    local idx = 1
    local list = {}
    local a = ""
    local iterator = string.gmatch(str,findstr)
    while true do
        a = { iterator() }
        if #a == 0 then break end
        fun(idx,unpack(a))
        idx = idx + 1
    end
end

return this