local this = {}
this.fileType = {
    { ".html", "text/html" },
    { ".css", "text/css" },
    -- {".js", "application/x-javascript"}, --����js�ļ�
    { ".js", "text/plain" },
    { ".xml", "text/plain" },
    { ".htm", "text/html" },
    { ".txt", "text/plain" },
    { ".mp3", "audio/x-mpeg" },

    { ".bmp", "image/bmp" },
    { ".gif", "image/gif" },
    { ".png", "image/png" },
    { ".jpg", "image/jpeg" },
    { ".jpeg", "image/jpeg" },
    { ".icon", "image/x-icon" },
    { ".ico", "image/x-icon" },

    { ".zip", "application/x-zip-compressed" },
    { ".rar", "application/octet-stream" },

    { ".xls", "application/vnd.ms-excel" },
    { ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" },
    { ".doc", "application/msword" },
    { ".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },

    { ".exe", "application/octet-stream" },
}

--����Ƿ�������ļ�����������������չ���Լ��������
function this.Check(_data)
    this.data = _data
    this.ctx = _data.ctx

    for i = 1, #this.fileType do
        local key = this.fileType[i][1]
        local val = this.fileType[i][2]
        this.fileType[key] = val
    end

    local tb = string.split("." .. this.data.LocalPath, "/")
    local last = tb[#tb]
    local result = {
        isWhiteFile = false,
        extension = "",
        fileType = "",
    }
    if last and string.find(last, ".") then
        local k = split(last, ".")
        local extension = k[#k]
        result.extension = "." .. extension
        if this.fileType[result.extension] then
            result.isWhiteFile = true
            result.fileType = this.fileType[result.extension]
        end
    end
    this.result = result

    return result.isWhiteFile
end

function this.DealFiles()
    local fileUrl = "." .. this.data.LocalPath
    log(string.format("files\t%s\t%s\t%s", this.ctx.Request.UserHostAddress, this.data.LocalPath,fileUrl))

    if Directory.Exists(fileUrl) then
        this.ctx.Response.ContentType = this.fileType[".html"];
        local t = Directory.GetFileSystemEntries(fileUrl)
        local iter = t:GetEnumerator()
        local str = "<ul>"
        while iter:MoveNext() do
            local url = iter.Current
            str = str .. string.format("<li><a href='.%s'>%s</a></li>", url, url)
        end
        str = str .. "</ul>"
        this.data.WriteResponse("<html>" .. str .. "</html>")
    elseif File.Exists(fileUrl) then
        this.ctx.Response.ContentType = this.result.fileType;
        if string.find(this.result.fileType, "application") then
            this.ctx.Response:AddHeader("Content-Disposition", "attachment;FileName=" .. fileUrl);
        end
        local fs = File.OpenRead(fileUrl)
        TBuffer(fs,this.ctx.Response.OutputStream):Copy(this.ctx)
    else
        this.data.returnJson({
            msg = "Not Fount File"
        })
        this.ctx.Response:Close();
    end
end

function this.DealCmd()
    log(string.format("ftp\t%s\t%s", this.ctx.Request.UserHostAddress, this.data.LocalPath))

    if this.result.isWhiteFile then
        local fileUrl = ""
        if ServerConfig.check_ftp_server then
            fileUrl = "." .. this.data.LocalPath
        else
            fileUrl = "." .. ServerConfig.ftp_files_root_url .. this.data.LocalPath
		end
        if File.Exists(fileUrl) then
            this.ctx.Response.ContentType = this.result.fileType;
            if string.find(this.result.fileType, "application") then
                this.ctx.Response:AddHeader("Content-Disposition", "attachment;FileName=" .. fileUrl);
            end
            local fs = File.OpenRead(fileUrl)
            TBuffer(fs,this.ctx.Response.OutputStream):Copy(this.ctx)
        else
            this.data.returnJson({
                msg = "Not Fount File"
            })
            this.ctx.Response:Close();
        end
    else
        this.data.returnJson({
            msg = "Not Fount Page"
        })
        this.ctx.Response:Close();
    end
end

return this