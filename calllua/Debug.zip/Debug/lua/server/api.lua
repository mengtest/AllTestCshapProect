local this = {}
this.data = {}

this.dellComFun = {
	[10030] = {
		[17] = function ()
			local data = {
				status = 1,
				data = {},
				msg = "1"
			}
			this.data.WriteResponse(cjson2.encode(data))
		end
	}
}

this.DealArgs = {
    ["/task"] = function ()
        local com = this.data.args["com"]
        local task = this.data.args["task"]
		if com and task then
			com = tonumber(com)
			task = tonumber(task)
            local comFun = this.dellComFun[com]
            if comFun and comFun[task] then
				comFun[task]()
				return 
            end
        end
		this.data.returnJson({
			error = 1,
			msg = "Not Found"
		})
    end,
    ["/favicon.ico"] = function ()
        
    end,
    ["/api"] = function()

    end,
}

function this.Check(_data)
    this.data = _data
    return this.DealArgs[this.data.LocalPath]
end

function this.DealCmd()
    log(string.format("api\t%s\t", this.data.LocalPath))
    this.data.ctx.Response:AddHeader("Content-Type", "application/json; charset=UTF-8");   --Ĭ�� json ����
    local fun = this.DealArgs[this.data.LocalPath] --·�ɴ�������
	if fun then
        fun()
    else
        this.data.returnJson({
            msg = "Not Fount"
        })
    end
    this.data.ctx.Response:Close();
end

return this