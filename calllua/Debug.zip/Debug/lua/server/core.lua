local this = {}

function this.RequestCallback(_ctx)
	local o = this.HandleCallBack(_ctx)
	o.ParseArgs()

    local ftp = require "lua.server.ftp"
    local api = require "lua.server.api"
    require "lua.server.config"
	if api.Check(o) then
		api.DealCmd()
	elseif ftp.Check(o) and ServerConfig.check_ftp_server then
		ftp.DealCmd()
	elseif ServerConfig.files_list_switch then
		ftp.DealFiles()
	else
		o.returnJson({
			msg = "Not Fount"
		})
		o.WriteResponse("<html>ʧ��</html>")
		o.ctx.Response:Close();
	end
end

function this.HandleCallBack(_ctx)
    local o = {}
    o.ctx = _ctx
    o.isGet = o.ctx.Request.HttpMethod == "GET"
    o.isPost = o.ctx.Request.HttpMethod == "POST"
    o.args = {}
    o.route = {}
    o.LocalPath = o.ctx.Request.Url.LocalPath
    function o.ParseArgs()--�����������
        if o.isGet then
            local QueryString = o.ctx.Request.QueryString
            local request = QueryString:GetEnumerator()
            while request:MoveNext() do
                local key = request.Current
                if key ~= nil then
                    local val = QueryString:Get(key)
                    o.args[key] = val
                end
            end
        elseif o.isPost then
            local render = StreamReader(o.ctx.Request.InputStream, Encoding.UTF8)
			local str = render:ReadToEnd()
            if str ~= "" then
                local all_kv = string.split(str, "&")
                for _, v in pairs(all_kv) do
                    local k_v = string.split(v, "=")
                    o.args[k_v[1]] = k_v[2]
                end
            end
        end
	end
	
    function o.WriteResponse(str)
        local writer = StreamWriter(o.ctx.Response.OutputStream, Encoding.UTF8)
        writer:Write(str);
        writer:Close();
    end

    function o.returnJson(obj)
        local json = JSON:encode(obj)
        o.WriteResponse(json)
    end

    return o
end

return this