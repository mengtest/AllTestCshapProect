ServerConfig = {
	check_ftp_server = true,	--处理ftp_files_root_url中的文件
	ftp_files_root_url = "/files",	--文件根目录
	files_list_switch = true,	--目录展示为文件列表
}